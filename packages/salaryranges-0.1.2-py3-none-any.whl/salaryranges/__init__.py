"""salaryranges 鈥?the published salary ranges from 259 companies, as plain Python.

No API key, no signup, no rate limit: the data is a static CSV that is rebuilt
weekly from public job boards (Greenhouse, Ashby, Lever, Workable, Personio,
Workday). Only postings that actually state a pay range are included, and every
number is normalised to an annual USD range in ``salary_usd_low`` /
``salary_usd_high``.

    >>> import salaryranges
    >>> rows = salaryranges.fetch()
    >>> len(rows) > 1000
    True
    >>> salaryranges.by_company("anthropic")[0]["salary_usd_low"] > 0
    True

Method, caveats and the raw CSV live at https://sjdfi0wjvosdju9.github.io/salary-data.html
"""

from __future__ import annotations

import csv
import io
import json
import os
import statistics
import time
import urllib.request
from typing import Any, Iterable

__version__ = "0.1.2"
__all__ = [
    "CSV_URL",
    "STATS_URL",
    "fetch",
    "stats",
    "by_company",
    "by_family",
    "by_ats",
    "median",
    "top",
    "as_frame",
    "clear_cache",
]

CSV_URL = "https://sjdfi0wjvosdju9.github.io/data/salary-ranges-full.csv"
CSV_SAMPLE_URL = "https://sjdfi0wjvosdju9.github.io/data/salary-ranges.csv"
STATS_URL = "https://sjdfi0wjvosdju9.github.io/data/salary-stats.json"
_USER_AGENT = "salaryranges/%s (+https://sjdfi0wjvosdju9.github.io/salary-data.html)" % __version__
_CACHE_HOURS = 24

INT_FIELDS = ("salary_usd_low", "salary_usd_high", "salary_usd_mid")


def _cache_dir() -> str:
    base = os.environ.get("SALARYRANGES_CACHE")
    if not base:
        root = os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
        base = os.path.join(root, "salaryranges")
    os.makedirs(base, exist_ok=True)
    return base


def clear_cache() -> None:
    """Delete the cached CSV so the next :func:`fetch` hits the network."""
    for name in ("salary-ranges-full.csv", "salary-stats.json"):
        path = os.path.join(_cache_dir(), name)
        if os.path.exists(path):
            os.remove(path)


def _download(url: str, filename: str, max_age_hours: float = _CACHE_HOURS) -> str:
    path = os.path.join(_cache_dir(), filename)
    fresh = os.path.exists(path) and (time.time() - os.path.getmtime(path)) < max_age_hours * 3600
    if fresh:
        return path
    request = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read()
    with open(path, "wb") as handle:
        handle.write(payload)
    return path


def fetch(offline: bool = False) -> list[dict[str, Any]]:
    """Return every row as a list of dicts with numeric salary fields.

    Results are cached for 24 hours in ``~/.cache/salaryranges``. Pass
    ``offline=True`` to require the cache and never touch the network.
    """
    if offline:
        path = os.path.join(_cache_dir(), "salary-ranges-full.csv")
        if not os.path.exists(path):
            raise FileNotFoundError("no cached CSV; call fetch() once with network access")
    else:
        path = _download(CSV_URL, "salary-ranges-full.csv")
    with open(path, newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        for field in INT_FIELDS:
            value = row.get(field)
            try:
                row[field] = int(value) if value not in (None, "") else None
            except (TypeError, ValueError):
                row[field] = None
        row["remote"] = str(row.get("remote", "")).lower() == "yes"
    return rows


def stats() -> dict[str, Any]:
    """The aggregate statistics JSON behind the data page (medians, per-board rates)."""
    path = _download(STATS_URL, "salary-stats.json")
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _match(value: str | None, needle: str) -> bool:
    if not isinstance(needle, str):
        needle = "" if needle is None else str(needle)
    if isinstance(value, (list, tuple)):
        value = " ".join(str(item) for item in value)
    return needle.lower() in ("" if value is None else str(value)).lower()


def _looks_like_rows(value: Any) -> bool:
    """True when *value* is a sequence of row dicts rather than a single label."""
    if value is None or isinstance(value, (str, bytes)):
        return False
    if isinstance(value, (list, tuple)):
        return True
    return hasattr(value, "__iter__")


def _rows_and_label(first: Any, second: Any) -> tuple[list[dict[str, Any]] | None, Any]:
    """Accept both ``fn(label, rows)`` and ``fn(rows, label)`` 鈥?people write both."""
    if _looks_like_rows(first) and not _looks_like_rows(second):
        return list(first), second
    return (list(second) if second is not None else None), first


def by_company(name: str, rows: Iterable[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Rows for one company. Substring match on ``company``, case-insensitive."""
    data, name = _rows_and_label(name, rows)
    data = data if data is not None else fetch()
    return [r for r in data if _match(r.get("company"), name)]


def by_family(family: str, rows: Iterable[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Rows for one role family (engineering, data, ml, product, sales, 鈥?."""
    data, family = _rows_and_label(family, rows)
    data = data if data is not None else fetch()
    return [r for r in data if _match(r.get("role_family"), family)]


def by_ats(ats: str, rows: Iterable[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Rows that came from one applicant tracking system (greenhouse, ashby, 鈥?."""
    data, ats = _rows_and_label(ats, rows)
    data = data if data is not None else fetch()
    return [r for r in data if _match(r.get("ats"), ats)]


def median(rows: Iterable[dict[str, Any]] | None = None) -> int | None:
    """Median of the midpoint of every range, in USD."""
    data = list(rows) if rows is not None else fetch()
    mids = [r["salary_usd_mid"] for r in data if r.get("salary_usd_mid")]
    return int(statistics.median(mids)) if mids else None


def top(n: int = 10, rows: Iterable[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """The ``n`` highest-paying rows. ``top(rows, 3)`` works too."""
    if _looks_like_rows(n):
        n, rows = (rows if isinstance(rows, int) else 10), n
    data = list(rows) if rows is not None else fetch()
    ranked = sorted((r for r in data if r.get("salary_usd_mid")), key=lambda r: -r["salary_usd_mid"])
    return ranked[: int(n)]


def as_frame(rows: Iterable[dict[str, Any]] | None = None):
    """Return a pandas DataFrame. Requires pandas; kept optional on purpose."""
    try:
        import pandas as pd  # noqa: F401
    except ImportError as exc:  # pragma: no cover
        raise ImportError("as_frame() needs pandas: pip install pandas") from exc
    data = list(rows) if rows is not None else fetch()
    return pd.DataFrame(data)
