"""Command line entry point: ``python -m salaryranges``."""

from __future__ import annotations

import argparse
import sys

from . import __version__, by_company, by_family, fetch, median, stats, top


def _money(value: int | None) -> str:
    return f"${value:,}" if value else "—"


def _print_rows(rows: list[dict], limit: int) -> None:
    if not rows:
        print("no rows matched")
        return
    width = max((len(str(r.get("company") or "")) for r in rows[:limit]), default=8)
    for row in rows[:limit]:
        company = str(row.get("company") or "").ljust(width)
        low, high = row.get("salary_usd_low"), row.get("salary_usd_high")
        band = f"${low:,}–${high:,}" if low and high else "—"
        remote = "remote" if row.get("remote") else "on-site"
        print(f"{company}  {band:>21}  {remote:8}  {row.get('title')}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="salaryranges",
        description="Published salary ranges from 259 companies, as plain Python. No key, no signup.",
    )
    parser.add_argument("--version", action="version", version=f"salaryranges {__version__}")
    sub = parser.add_subparsers(dest="command")

    p_top = sub.add_parser("top", help="highest-paying rows")
    p_top.add_argument("-n", "--limit", type=int, default=10)

    p_co = sub.add_parser("company", help="rows for one company")
    p_co.add_argument("name")
    p_co.add_argument("-n", "--limit", type=int, default=10)

    p_fam = sub.add_parser("family", help="rows for one role family")
    p_fam.add_argument("name")
    p_fam.add_argument("-n", "--limit", type=int, default=10)

    sub.add_parser("stats", help="aggregate statistics")

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 0

    if args.command == "stats":
        data = stats()
        print(f"generated        {data.get('generated_at')}")
        print(f"companies        {data.get('companies_in_pool')}")
        print(f"postings scanned {data.get('postings_scanned'):,}")
        print(f"with a salary    {data.get('postings_with_salary'):,} ({data.get('share_with_salary')}%)")
        print(f"median midpoint  {_money(data.get('median_mid'))}")
        print()
        print("board        postings  with salary   rate")
        for row in data.get("publication_by_ats", []):
            print(f"{row['ats']:<12} {row['postings']:>8,} {row['with_salary']:>11,} {row['rate']:>6}%")
        return 0

    rows = fetch()
    if args.command == "top":
        rows = top(args.limit, rows)
    elif args.command == "company":
        rows = by_company(args.name, rows)
    elif args.command == "family":
        rows = by_family(args.name, rows)
    _print_rows(rows, args.limit)
    print(f"\nmedian midpoint over everything: {_money(median(fetch()))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
